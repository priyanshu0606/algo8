<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">

    <!-- viewport meta -->
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Startai - Bootstrap4 Agency & Startup HTML Template">
    <meta name="keywords" content="Startai, ai, artificial intelligence, machine learning">

    <title>Algo8 Blog-Details</title>

    <!-- inject:css -->

    <link rel="stylesheet" href="css/font-awesome.min.css">

    <link rel="stylesheet" href="css/magnific-popup.css">

    <link rel="stylesheet" href="css/normalize.css">

    <link rel="stylesheet" href="css/owl.carousel.min.css">

    <link rel="stylesheet" href="css/simple-line-icons.css">

    <link rel="stylesheet" href="css/bootstrap/bootstrap.min.css">

    <link rel="stylesheet" href="style.css">

    <!-- endinject -->
</head>

<body>
    <!-- Header Starts -->
    <header>
        <!-- Starts: .header-top -->
        <div class="header-top">
            <div class="container">
                <div class="row">
                    <div class="col-md-6 top-left">
                        <ul class="list-unstyled">
                            <li>
                                <span class="icon-envelope-open"></span> <a href="/cdn-cgi/l/email-protection" class="__cf_email__" data-cfemail="3841574d4a55595154785c5755595156165b5755">[email&#160;protected]</a></li>
                            <li>
                                <span class="icon-phone"></span> +123-456789
                            </li>
                        </ul>
                    </div>
                    <div class="col-md-6 top-right">
                        <ul class="list-unstyled">
                            <li>
                                <a href="">FR</a>
                            </li>
                            <li>
                                <a href="">PO</a>
                            </li>
                            <li>
                                <a href="">SP</a>
                            </li>
                            <li>
                                <a href="">EN</a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <!-- Ends: .header-top -->

        <!-- Starts: .main-menu -->
        <div class="main-menu">
            <div class="container">
                <nav class="navbar navbar-expand-lg">
                    <a class="navbar-brand" href="index.html">
                        <img src="images/logo.png" alt="">
                    </a>
                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown"
                        aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon icon-menu"></span>
                    </button>
                    <div class="collapse navbar-collapse" id="navbarNavDropdown">
                        <ul class="navbar-nav">
                            <li class="nav-item">
                                <a class="nav-link" href="index.html">Home</a>
                            </li>
                            <li class="nav-item dropdown">
                                <a class="nav-link dropdown-toggle" href="#" data-toggle="dropdown">Pages</a>
                                <div class="dropdown-menu">
                                    <a class="dropdown-item" href="about.html">About</a>
                                    <a class="dropdown-item" href="projects.html">Project</a>
                                    <a class="dropdown-item" href="project-details.html">Project Details</a>
                                    <a class="dropdown-item" href="publications.html">Publications</a>
                                    <a class="dropdown-item" href="research.html">Research</a>
                                    <a class="dropdown-item" href="events.html">Events</a>
                                    <a class="dropdown-item" href="careers.html">Careers</a>
                                    <a class="dropdown-item" href="career-details.html">Career Details</a>
                                    <a class="dropdown-item" href="contact.html">Contact</a>
                                </div>
                            </li>
                            <li class="nav-item dropdown">
                                <a class="nav-link dropdown-toggle" href="#" data-toggle="dropdown">Projects</a>
                                <div class="dropdown-menu">
                                    <a class="dropdown-item" href="projects.html">Project</a>
                                    <a class="dropdown-item" href="project-details.html">Project Details</a>
                                </div>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="about.html">About</a>
                            </li>
                            <li class="nav-item dropdown">
                                <a class="nav-link dropdown-toggle" href="#" data-toggle="dropdown">Career</a>
                                <div class="dropdown-menu">
                                    <a class="dropdown-item" href="careers.html">Careers</a>
                                    <a class="dropdown-item" href="career-details.html">Career Details</a>
                                </div>
                            </li>
                            <li class="nav-item dropdown active">
                                <a class="nav-link dropdown-toggle" href="#" data-toggle="dropdown">Blog</a>
                                <div class="dropdown-menu">
                                    <a class="dropdown-item" href="blog-classic.html">Blog Classic</a>
                                    <a class="dropdown-item" href="blog-sidebar.html">Blog Sidebar</a>
                                    <a class="dropdown-item" href="blog-details.html">Blog Details</a>
                                </div>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="contact.html">Contact</a>
                            </li>
                            <li class="nav-item">
                                <ul class="list-unstyled">
                                    <li class="nav-search-wrap">
                                        <a href="#" class="nav-link nav-search search-trigger">
                                            <i class="icon-magnifier"></i>
                                        </a>
                                    </li>
                                    <li class="nav-icon-wrap d-sm-none">
                                        <div id="nav-icon">
                                            <div class="nav-icon-inner">
                                                <a href="#" id="nav-icon-trigger" class="nav-icon-trigger">
                                                    <span></span>
                                                    <span></span>
                                                    <span></span>
                                                    <span></span>
                                                </a>
                                            </div>
                                        </div>
                                    </li>
                                </ul>
                            </li>
                            <!-- Ends .nav-right -->
                        </ul>
                    </div>
                </nav>
                <!-- Fullscreen search -->
                <div class="search-wrap">
                    <div class="search-inner">
                        <div class="search-cell">
                            <form method="get">
                                <div class="search-field-holder">
                                    <input type="search" class="form-control main-search-input" placeholder="Type & hit enter...">
                                    <i class="icon-close" id="search-close"></i>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <!-- end fullscreen search -->
            </div>
        </div>
        <!-- Ends: .main-menu -->
    </header>
    <!-- Ends: header -->

    <!-- Start: .pages-header -->
    <div class="pages-header">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <h1>Blog Details</h1>
                    <ul class="breadcrumbs">
                        <li>
                            <a href="">
                                <span class="icon-home"></span> Home
                            </a>
                        </li>
                        <li class="active">Blog Details</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <!-- Ends: .pages-header -->

    <!-- Starts: .blog-wrapper -->
    <section class="blog-wrapper section-padding" style="widht:100%">
        <div class="container">
            <div class="row">
                <div class="col-lg-9">
                    <div class="blog-details">
                        <figure class="blog-thumb">
                            <img src="images/blog1.png" alt="" class="img-fluid">
                            <figcaption>
                                <span class="blog-badge">
                                    <span>29</span> Apr
                                </span>
                            </figcaption>
                        </figure>
                        <div class="blog-contents">
                            <h2 class="blog-title">Standard single image post</h2>
                            <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been
                                the industry's stand dummy text ever since the 1500s, when an unknown printer took a galley
                                of type and scrambled it to make a neque a tortor tempor in porta sem vulputate. Donec varius
                                felis fermentum nis type specimen book. It has survived not only five centuries.Phasellus
                                vehicula justo eget diam posuere sollicitudin eu tincidunt nulla. Curabitur eleifend tempor
                                magna, in scelerisque urna placerat vel. Phasellus eget sem id justo consequat egestas quis
                                facilisis metus.Phasellus vehicula justo eget diam posuere sollicitudin eu tincidunt nulla.
                                Curabitur eleifend tempor magna, in scelerisque urna placerat vel. Phasellus eget sem id
                                justo consequat egestas quis facilisis metus.</p>
                            <blockquote>
                                <span class="icon-speech"></span> " Vivamus sit amet lectus venenatis est rhoncus interdum a vitae velit Massa sagittis
                                vesti bulum. Vestib ulum pretium blandit tellus, sodales volutpat sapien varius vel. Phasellus
                                tris tique cursus erat, a placerat tellus laoreet egeat. Fusce vitae dui sit amet lacus rutrum
                                convallis. Vivamus sit amet lectus vene natis est rhoncus interdum a vitae velit sodales
                                volutpat sapien varius vel. " </blockquote>
                            <p>Suspendisse blandit ligula turpis, ac convallis risus fermentum non. Duis vestibulum quis quam
                                vel accumsan. Nunc a vulputate lectus. Vestibulum eleifend nisl sed massa sagittis vestibulum.
                                Vestibulum pretium blandit tellus, sodales volutpat sapien varius vel. Phasellus tristique
                                cursus erat, a placerat tellus laoreet eget. Fusce vitae dui sit amet lacus rutrum convallis.
                                Vivamus sit amet lectus venenatis est rhoncus interdum a vitae velit. Suspendisse blandit
                                ligula turpis, ac convallis risus fermentum non. Duis vestibulum quis quam vel accumsan.
                                Nunc a vulputate lectus. Vestibulum eleifend nisl sed massa sagittis vestibulum. Vestibulum
                                pretium blandit tellus, sodales volutpat sapien varius vel. Phasellus tristique cursus erat,
                                a placerat tellus laoreet eget. Fusce vitae dui sit amet lacus rutrum convallis. Vivamus
                                sit amet lectus venenatis est rhoncus interdum a vitae velit.</p>
                            <p>Massa sagittis vestibulum. Vestibulum pretium blandit tellus, sodales volutpat sapien varius
                                vel. Phasellus tristique cursus erat, a placerat tellus laoreet eget. Fusce vitae dui sit
                                amet lacus rutrum convallis. Vivamus sit amet lectus venenatis est rhoncus interdum a vitae
                                velit.
                            </p>

                            <div class="post-bottom-excerpt">
                                <ul class="list-unstyled">
                                    <li class="post-author">
                                        <span class="icon-user"></span> Posted By:
                                        <a href="">Jessica Browen</a>
                                    </li>
                                    <li class="post-comment">
                                        <a href="">
                                            <span class="icon-bubble"></span> 31 Comments
                                        </a>
                                    </li>
                                    <li class="post-likes">
                                        <a href="">
                                            <span class="icon-heart"></span> 44 Likes
                                        </a>
                                    </li>
                                    <li class="post-tags">
                                        <span class="icon-tag"></span>
                                        <a href="">Automation</a>,
                                        <a href="">Machine</a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <!-- Ends: .blog-contents -->
                    </div>
                    <!-- Ends: .blog-details -->

                    <div class="project-pagination">
                        <ul class="list-unstyled">
                            <li>
                                <a href="">
                                    <span class="icon-arrow-left"></span> Prev</a>
                            </li>
                            <li>
                                <a href="">
                                    <span class="icon-grid"></span>
                                </a>
                            </li>
                            <li>
                                <a href="">Next
                                    <span class="icon-arrow-right"></span>
                                </a>
                            </li>
                        </ul>
                    </div>
                    <!-- Ends: .pagination -->

                    <div class="related-projects">
                        <div class="row">
                            <div class="col-md-12">
                                <h2 class="section--title">Related
                                    <span>Blogs</span>
                                </h2>
                            </div>
                            <!-- Ends: .section-title -->
                            <div class="col-lg-4 col-md-6">
                                <div class="project-single">
                                    <figure>
                                        <img src="images/project-8.jpg" alt="" class="img-fluid">
                                        <figcaption>
                                            <h3>Intelligent customer service</h3>
                                            <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Ullam dolorum illum
                                                recusandae voluptates
                                            </p>
                                            <a href="">Read More
                                                <span class="icon-arrow-right"></span>
                                            </a>
                                        </figcaption>
                                    </figure>
                                </div>
                            </div>
                            <!-- Ends: .col-md-6 -->
                            <div class="col-lg-4 col-md-6">
                                <div class="project-single">
                                    <figure>
                                        <img src="images/project-4.jpg" alt="" class="img-fluid">
                                        <figcaption>
                                            <h3>Intelligent customer service</h3>
                                            <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Ullam dolorum illum
                                                recusandae voluptates
                                            </p>
                                            <a href="">Read More
                                                <span class="icon-arrow-right"></span>
                                            </a>
                                        </figcaption>
                                    </figure>
                                </div>
                            </div>
                            <!-- Ends: .col-md-6 -->
                            <div class="col-lg-4 col-md-6">
                                <div class="project-single">
                                    <figure>
                                        <img src="images/project-1.jpg" alt="" class="img-fluid">
                                        <figcaption>
                                            <h3>Intelligent customer service</h3>
                                            <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Ullam dolorum illum
                                                recusandae voluptates
                                            </p>
                                            <a href="">Read More
                                                <span class="icon-arrow-right"></span>
                                            </a>
                                        </figcaption>
                                    </figure>
                                </div>
                            </div>
                            <!-- Ends: .col-md-6 -->
                        </div>
                    </div>
                    <!-- Ends: .related-projects -->

                    <div class="post-comments">
                        <h2 class="section--title">03
                            <span>Comments</span>
                        </h2>
                        <div class="comments-list">
                            <div class="comment-single">
                                <div class="comment-details">
                                    <div class="author-avater">
                                        <img src="images/auth1.png" alt="" class="img-fluid rounded-circle">
                                    </div>
                                    <div class="author-comment">
                                        <h4>David Jhon</h4>
                                        <span>Apr 28, 2018</span>
                                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem
                                            Ipsum has been the industry's stand dummy text ever since the 1500s, when an
                                            unknown printer took.
                                        </p>
                                    </div>
                                    <a href="" class="reply-btn">Reply</a>
                                </div>
                                <!-- Ends: .comment-details -->
                                <div class="comment-replys">
                                    <div class="comment-single">
                                        <div class="comment-details">
                                            <div class="author-avater">
                                                <img src="images/auth2.png" alt="" class="img-fluid rounded-circle">
                                            </div>
                                            <div class="author-comment">
                                                <h4>Jessica Browen</h4>
                                                <span>Apr 28, 2018</span>
                                                <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.
                                                    Lorem Ipsum has been the industry's stand dummy text ever since the 1500s,
                                                    when an unknown printer took.
                                                </p>
                                            </div>
                                            <a href="" class="reply-btn">Reply</a>
                                        </div>

                                    </div>
                                    <!-- Ends: .comment-single -->
                                </div>
                                <!-- Ènds: .comment-replys -->
                            </div>
                            <!-- Ends: .comment-single -->
                            <div class="comment-single">
                                <div class="comment-details">
                                    <div class="author-avater">
                                        <img src="images/auth3.png" alt="" class="img-fluid rounded-circle">
                                    </div>
                                    <div class="author-comment">
                                        <h4>Heidi Culm</h4>
                                        <span>Apr 28, 2018</span>
                                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem
                                            Ipsum has been the industry's stand dummy text ever since the 1500s, when an
                                            unknown printer took.
                                        </p>
                                    </div>
                                    <a href="" class="reply-btn">Reply</a>
                                </div>

                            </div>
                            <!-- Ends: .comment-single -->
                        </div>
                        <!-- Ends: .comments-list -->
                    </div>
                    <!-- Ends: .post-comments -->

                    <div class="comment-form">
                        <h2 class="section--title">Post a
                            <span>Comment</span>
                        </h2>
                        <form action="#">
                            <div class="form-group">
                                <div class="row">
                                    <div class="col-md-6">
                                        <label>Your Name</label>
                                        <input type="text" required>
                                    </div>
                                    <div class="col-md-6">
                                        <label>Your Email</label>
                                        <input type="email" required>
                                    </div>
                                    <div class="col-md-12">
                                        <label>Your Message</label>
                                        <textarea placeholder="Write message here" required></textarea>
                                        <button type="submit">Post Comment</button>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
                <!-- Ends: .col-lg-8 -->

            </div>
        </div>
        <!-- Ends: .contianer -->
    </section>
    <!-- Ends: .blog-wrapper -->

    <!-- Starts: Call To Action -->
    <section class="cta">
        <div class="container">
            <div class="row">
                <div class="col-md-12 cta-contents">
                    <h2>You are one step closer to start your AI project</h2>
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptatibus aperiam qui doloribus.</p>
                    <a href="" class="btn btn-large">Start Now
                        <span class="icon-paper-plane"></span>
                    </a>
                </div>
            </div>
        </div>
    </section>
    <!-- Ends: .cta -->

    <!-- Starts: Footer -->
    <footer>
        <div class="container">
            <div class="row">
                <div class="col-lg-3 col-md-6">
                    <div class="widget-area">
                        <div class="widget-head">
                            <img src="images/logo-white.png" alt="" class="img-fluid">
                        </div>
                        <div class="widget-contents">
                            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Provident dolores veritatis minima harum
                                similique, vel earum vitae sed hic odio.</p>
                            <ul class="list-unstyled footer-address">
                                <li>
                                    <span class="icon-envelope-open"></span> <a href="/cdn-cgi/l/email-protection" class="__cf_email__" data-cfemail="ccafa3a2b8adafb88cb5a3b9bea1ada5a0e2afa3a1">[email&#160;protected]</a></li>
                                <li>
                                    <span class="icon-phone"></span> +0123-456789</li>
                                <li>
                                    <span class="icon-paper-plane"></span> Washington Avenue, NY 3568</li>
                            </ul>
                            <!-- Ends: .footer-address -->
                            <ul class="list-unstyled footer-social">
                                <li>
                                    <a href="">
                                        <span class="icon-social-facebook"></span>
                                    </a>
                                </li>
                                <li>
                                    <a href="">
                                        <span class="icon-social-twitter"></span>
                                    </a>
                                </li>
                                <li>
                                    <a href="">
                                        <span class="icon-social-linkedin"></span>
                                    </a>
                                </li>
                                <li>
                                    <a href="">
                                        <span class="icon-social-instagram"></span>
                                    </a>
                                </li>
                            </ul>
                            <!-- Ends: .footer-social -->
                        </div>
                    </div>
                </div>
                <!-- Ends: .col-md-3 -->

                <div class="col-lg-3 col-md-6">
                    <div class="widget-area latest-post-widget">
                        <div class="widget-head">
                            <h2>
                                <span class="icon-logout"></span> Latest Posts</h2>
                        </div>
                        <div class="widget-contents">
                            <div class="lp-single">
                                <div class="lp-thumb">
                                    <a href="">
                                        <img src="images/blog-thumb1.png" alt="" class="img-fluid">
                                    </a>
                                </div>
                                <div class="lp-desc">
                                    <h3>
                                        <a href="">Project seminer AI</a>
                                    </h3>
                                    <span>Apr 12, 2018</span>
                                </div>
                            </div>
                            <!-- Ends: .lp-single -->
                            <div class="lp-single">
                                <div class="lp-thumb">
                                    <a href="">
                                        <img src="images/blog-thumb2.png" alt="" class="img-fluid">
                                    </a>
                                </div>
                                <div class="lp-desc">
                                    <h3>
                                        <a href="">Lorem ipsum dolor</a>
                                    </h3>
                                    <span>Apr 12, 2018</span>
                                </div>
                            </div>
                            <!-- Ends: .lp-single -->
                            <div class="lp-single">
                                <div class="lp-thumb">
                                    <a href="">
                                        <img src="images/blog-thumb3.png" alt="" class="img-fluid">
                                    </a>
                                </div>
                                <div class="lp-desc">
                                    <h3>
                                        <a href="">AI Project Seminer</a>
                                    </h3>
                                    <span>Apr 12, 2018</span>
                                </div>
                            </div>
                            <!-- Ends: .lp-single -->
                            <div class="lp-single">
                                <div class="lp-thumb">
                                    <a href="">
                                        <img src="images/blog-thumb4.png" alt="" class="img-fluid">
                                    </a>
                                </div>
                                <div class="lp-desc">
                                    <h3>
                                        <a href="">Aicta nostrum error</a>
                                    </h3>
                                    <span>Apr 12, 2018</span>
                                </div>
                            </div>
                            <!-- Ends: .lp-single -->
                        </div>
                        <!-- Ends: .widget-contents -->
                    </div>
                </div>
                <!-- Ends: .col-md-3 -->

                <div class="col-lg-3 col-md-6">
                    <div class="widget-area links">
                        <div class="widget-head">
                            <h2>
                                <span class="icon-logout"></span> Useful Links</h2>
                        </div>
                        <div class="widget-contents">
                            <ul class="list-unstyled">
                                <li>
                                    <a href="">
                                        <span class="fa fa-angle-right"></span> Home
                                    </a>
                                </li>
                                <li>
                                    <a href="">
                                        <span class="fa fa-angle-right"></span> About Us
                                    </a>
                                </li>
                                <li>
                                    <a href="">
                                        <span class="fa fa-angle-right"></span> Solutions
                                    </a>
                                </li>
                                <li>
                                    <a href="">
                                        <span class="fa fa-angle-right"></span> Contact
                                    </a>
                                </li>
                                <li>
                                    <a href="">
                                        <span class="fa fa-angle-right"></span> Projects
                                    </a>
                                </li>
                                <li>
                                    <a href="">
                                        <span class="fa fa-angle-right"></span> FAQ's
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
                <!-- Ends: .col-md-3 -->

                <div class="col-lg-3 col-md-6">
                    <div class="widget-area sibscribe-widget">
                        <div class="widget-head">
                            <h2>
                                <span class="icon-logout"></span> Subscribe Us</h2>
                        </div>
                        <div class="widget-contents">
                            <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Possimus, earum!</p>

                            <form action="#">
                                <div class="form-group">
                                    <div class="input">
                                        <span>
                                            <i class="fa fa-envelope-o"></i>
                                        </span>
                                        <input type="text" placeholder="Your Name">
                                    </div>
                                    <div class="mail">
                                        <span>
                                            <i class="fa fa-phone"></i>
                                        </span>
                                        <input type="email" placeholder="Type Your Email">
                                    </div>
                                    <button type="submit">Subscribe</button>
                                </div>
                            </form>
                        </div>
                        <!-- Ends: .widget-contents -->
                    </div>
                </div>
                <!-- Ends: .col-md-3 -->

                <div class="col-md-12">
                    <div class="footer-bottom">
                        <p>&copy; Copyright 2018
                            <a href="https://snazzytheme.com">SnazzyTheme</a> | All Rights Reserved</p>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!-- Ends: Footer -->

    <!-- ==============================================
        JS GOES HERE
    ================================================= -->

    <!-- inject:js -->

    <script data-cfasync="false" src="/cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script><script src="js/vendor/jquery/jquery-1.12.3.js"></script>

    <script src="js/vendor/jquery/particles.min.js"></script>

    <script src="js/vendor/jquery/popper.min.js"></script>

    <script src="js/vendor/bootstrap.min.js"></script>

    <script src="js/vendor/jquery.magnific-popup.min.js"></script>

    <script src="js/vendor/jquery.sticky.js"></script>

    <script src="js/vendor/owl.carousel.min.js"></script>

    <script src="js/vendor/particles-app.js"></script>

    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDMjWSDG4QO9RnoYOsLOKITmRLbkg6B5TM"></script>
    <script src="js/vendor/gmap.js"></script>

    <script src="js/main.js"></script>

    <!-- endinject -->



</body>

</html>