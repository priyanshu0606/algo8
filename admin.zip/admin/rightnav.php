<ul>
<li><a href="images.php">Add Images & Slider Text</a></li>
<li><a href="addcat.php">Add Categories</a></li>
<li><a href="addcat.php">Add a New Job</a></li>
<li><a href="clients.php">Our Clients</a></li>
<li><a href="addblog.php">Blogs</a></li>
<li><a href="addheader.php">Header</a></li>
<li><a href="addfooter.php">Footer</a></li>
</ul>
							

