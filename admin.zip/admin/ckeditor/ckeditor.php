<html>
<head>
<script src="ckeditor/ckeditor.js"></script>
</head>
<body>
<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
  <textarea name="text" id="text">This is a demo text.</textarea>
  <script>
  CKEDITOR.replace( 'text' );
  </script>
  <input type="submit" value="Save Changes" name="submit">
  </form>

</body>
</html>