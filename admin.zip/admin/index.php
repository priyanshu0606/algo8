<?php
session_start();
include('connect.php');
if(isset($_POST["submit"])) {

$u="";
$p="";
if(isset($_POST["u"])) {
	$u=$_POST['u'];
}
if(isset($_POST["p"])) {
	$p=	$_POST['p'];
}
$result=mysql_query("select * from tbllogin where username='$u' and password='$p'");
$r=mysql_num_rows($result);
$r1=mysql_fetch_array($result);
$_SESSION["uid"]=$r1['id'];

if($r>0)
{
	$_SESSION["id"]=$u;
	
	header('location:welcome.php');	
}
else{
	echo "<script type='text/javascript'>alert('Either Username/Password detail does not match...')</script>";
}
		
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title> Admin - Login</title>
<link rel="stylesheet" type="text/css" href="css/meta-admin-login.css">
<!-- blue theme is default -->

<link rel="stylesheet" type="text/css" href="css/grey-theme-login.css">

<!--[if lte IE 6]><link media="screen" rel="stylesheet" type="text/css" href="css/ie-login.css" /><![endif]-->
</head>

<body>
	<!--[if !IE]>start wrapper<![endif]-->
	<div id="wrapper">
		<!--[if !IE]>start header<![endif]-->
		<div id="header">
			<div class="inner">
				<h1 id="logo"><a href="#">Adminstration Panel</a></h1>
			</div>
		</div>
		<!--[if !IE]>end header<![endif]-->
		<!--[if !IE]>start content<![endif]-->
		<div id="content">
			
				<!--[if !IE]>start login_wrapper<![endif]-->
				<div id="login_wrapper">
					<span class="extra1"></span>
					<div class="title_wrapper">
						<h2>Please Login</h2>
						
					</div>
					
					
					<form method="post">
						<fieldset>
							<!--[if !IE]>start row<![endif]-->
							
					
							<div class="row">
								<label>Username:</label>
								<span class="input_wrapper">
									<input class="text" name="u" type="text" required  placeholder="Username"/>
								</span>
							</div>
							<!--[if !IE]>end row<![endif]-->
							<!--[if !IE]>start row<![endif]-->
							<div class="row">
								<label>Password:</label>
								<span class="input_wrapper">
									<input class="text" name="p" type="password" required placeholder="Password" />
								</span>
							</div>
							<!--[if !IE]>end row<![endif]-->
							<!--[if !IE]>start row<![endif]-->
							<div class="row">
								
							</div>
							<!--[if !IE]>end row<![endif]-->
							<!--[if !IE]>start row<![endif]-->
								<div class="row">
									<div class="inputs small_inputs">
										<span class="button blue_button unlock_button"><span><span><em><span a href="welcome.php" class="button_ico"></span>Login</em></span></span><input name="submit" type="submit"></span>
										<a href="http://localhost/myshop/index.php" class="button gray_button"><span><span>Back to site</span></span></a> 
									</div>
								</div>
								
									
								<!--[if !IE]>end row<![endif]-->
						</fieldset>
					</form>
				</div>
				<!--[if !IE]>end login_wrapper<![endif]-->
			
		</div>
		<!--[if !IE]>end content<![endif]-->
	</div>
	<!--[if !IE]>end wrapper<![endif]-->


</body></html>