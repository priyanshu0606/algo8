
<?php


include("db/connect.php");
?>
<?php
if(isset($_GET['edit'])){
$id=$_GET['edit'];
$sql="SELECT * FROM tblpic where id='$id'";
$result = mysql_query($sql);
$row = mysql_fetch_array($result);
}
?>
<?php

if(isset($_POST['submit']))
{
if ((($_FILES["file"]["type"] == "image/gif")
|| ($_FILES["file"]["type"] == "image/jpeg")
|| ($_FILES["file"]["type"] == "image/png"))
&& ($_FILES["file"]["size"] < 2000000000))
  {
  if ($_FILES["file"]["error"] > 0)
    {
    echo "Return Code: " . $_FILES["file"]["error"] . "<br />";
    }
  else
    {
    /*echo "Upload: " . $_FILES["file"]["name"] . "<br />";
    echo "Type: " . $_FILES["file"]["type"] . "<br />";
    echo "Size: " . ($_FILES["file"]["size"] / 1024) . " Kb<br />";
    echo "Temp file: " . $_FILES["file"]["tmp_name"] . "<br />";*/

    if (file_exists("upload/" . $_FILES["file"]["name"]))
      {
      echo $_FILES["file"]["name"] . " already exists. ";
      }
    else
      {
	  $img=$_FILES["file"]["name"];
      move_uploaded_file($_FILES["file"]["tmp_name"],"images/gallery/" . $img);
     
      }
	 
	$id=$_GET['edit'];
$sql=("update tblpic set picname='$img' where id='$id'");
mysql_query($sql);
	header("Location:dashboard.php?url=addgallery");
	}
  }
}

?>
	<table width=100% style="float:left;">
<form action="" method=post enctype="multipart/form-data">

<tr><td height=40><h3>Add Image</h3></td></tr>
<tr><td>
<label>Attach Image:</label><input name="file"  type="file" />
</td></tr>
<tr>
<td>
<img src="images/gallery/<?php echo $row['picname']; ?>" alt="" width="200px" height="200px"/>
</td>
</tr>
<tr><td>
<input type="submit" name="submit" value="Submit">
</td></tr>
</form>
</table>