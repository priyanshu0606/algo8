<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title>Meta Admin - Administration Clever Panel</title>
<link rel="stylesheet" type="text/css" href="faq_files/meta-admin.css">
<!-- blue theme is default -->

<link rel="stylesheet" type="text/css" href="faq_files/grey-theme.css">

<script type="text/javascript" src="faq_files/css.htm"></script>
<script type="text/javascript" src="faq_files/behaviour.htm"></script>


<!-- text editor -->
	
	<!-- TinyMCE -->
<script type="text/javascript" src="faq_files/tiny_mce.js"></script>
<script type="text/javascript">
	tinyMCE.init({
		// General options
		mode : "textareas",
		theme : "advanced",
		plugins : "pagebreak,style,layer,table,save,advhr,advimage,advlink,emotions,iespell,inlinepopups,insertdatetime,preview,media,searchreplace,print,contextmenu,paste,directionality,fullscreen,noneditable,visualchars,nonbreaking,xhtmlxtras,template,wordcount,advlist,autosave",

		// Theme options
		theme_advanced_buttons1 : "save,newdocument,|,bold,italic,underline,strikethrough,|,justifyleft,justifycenter,justifyright,justifyfull,styleselect,formatselect,fontselect,fontsizeselect",
		theme_advanced_buttons2 : "cut,copy,paste,pastetext,pasteword,|,search,replace,|,bullist,numlist,|,outdent,indent,blockquote,|,undo,redo,|,link,unlink,anchor,image,cleanup,help,code,|,insertdate,inserttime,preview,|,forecolor,backcolor",
		theme_advanced_buttons3 : "tablecontrols,|,hr,removeformat,visualaid,|,sub,sup,|,charmap,emotions,iespell,media,advhr,|,print,|,ltr,rtl,|,fullscreen",
		theme_advanced_buttons4 : "insertlayer,moveforward,movebackward,absolute,|,styleprops,|,cite,abbr,acronym,del,ins,attribs,|,visualchars,nonbreaking,template,pagebreak,restoredraft",
		theme_advanced_toolbar_location : "top",
		theme_advanced_toolbar_align : "left",
		theme_advanced_statusbar_location : "bottom",
		theme_advanced_resizing : true,

		// Example content CSS (should be your site CSS)
		content_css : "css/content.css",

		// Drop lists for link/image/media/template dialogs
		template_external_list_url : "lists/template_list.js",
		external_link_list_url : "lists/link_list.js",
		external_image_list_url : "lists/image_list.js",
		media_external_list_url : "lists/media_list.js",

		// Style formats
		style_formats : [
			{title : 'Bold text', inline : 'b'},
			{title : 'Red text', inline : 'span', styles : {color : '#ff0000'}},
			{title : 'Red header', block : 'h1', styles : {color : '#ff0000'}},
			{title : 'Example 1', inline : 'span', classes : 'example1'},
			{title : 'Example 2', inline : 'span', classes : 'example2'},
			{title : 'Table styles'},
			{title : 'Table row 1', selector : 'tr', classes : 'tablerow1'}
		],

		// Replace values for the template plugin
		template_replace_values : {
			username : "Some User",
			staffid : "991234"
		}
	});
</script>



<style>.cke{visibility:hidden;}</style><script src="faq_files/editor_template.htm" type="text/javascript" id="mce_1"></script><script src="faq_files/editor_plugin_003.htm" type="text/javascript" id="mce_2"></script><script src="faq_files/editor_plugin.htm" type="text/javascript" id="mce_3"></script><script src="faq_files/editor_plugin_005.htm" type="text/javascript" id="mce_4"></script><script src="faq_files/editor_plugin_016.htm" type="text/javascript" id="mce_5"></script><script src="faq_files/editor_plugin_008.htm" type="text/javascript" id="mce_6"></script><script src="faq_files/editor_plugin_023.htm" type="text/javascript" id="mce_7"></script><script src="faq_files/editor_plugin_020.htm" type="text/javascript" id="mce_8"></script><script src="faq_files/editor_plugin_022.htm" type="text/javascript" id="mce_9"></script><script src="faq_files/editor_plugin_024.htm" type="text/javascript" id="mce_10"></script><script src="faq_files/editor_plugin_017.htm" type="text/javascript" id="mce_11"></script><script src="faq_files/editor_plugin_018.htm" type="text/javascript" id="mce_12"></script><script src="faq_files/editor_plugin_015.htm" type="text/javascript" id="mce_13"></script><script src="faq_files/editor_plugin_013.htm" type="text/javascript" id="mce_14"></script><script src="faq_files/editor_plugin_025.htm" type="text/javascript" id="mce_15"></script><script src="faq_files/editor_plugin_012.htm" type="text/javascript" id="mce_16"></script><script src="faq_files/editor_plugin_009.htm" type="text/javascript" id="mce_17"></script><script src="faq_files/editor_plugin_002.htm" type="text/javascript" id="mce_18"></script><script src="faq_files/editor_plugin_019.htm" type="text/javascript" id="mce_19"></script><script src="faq_files/editor_plugin_011.htm" type="text/javascript" id="mce_20"></script><script src="faq_files/editor_plugin_004.htm" type="text/javascript" id="mce_21"></script><script src="faq_files/editor_plugin_026.htm" type="text/javascript" id="mce_22"></script><script src="faq_files/editor_plugin_010.htm" type="text/javascript" id="mce_23"></script><script src="faq_files/editor_plugin_028.htm" type="text/javascript" id="mce_24"></script><script src="faq_files/editor_plugin_007.htm" type="text/javascript" id="mce_25"></script><script src="faq_files/editor_plugin_006.htm" type="text/javascript" id="mce_26"></script><script src="faq_files/editor_plugin_014.htm" type="text/javascript" id="mce_27"></script><script src="faq_files/editor_plugin_021.htm" type="text/javascript" id="mce_28"></script><script src="faq_files/editor_plugin_027.htm" type="text/javascript" id="mce_29"></script><script src="faq_files/config.js" type="text/javascript"></script><link href="faq_files/editor_gecko.css" type="text/css" rel="stylesheet"><script src="faq_files/en.js" type="text/javascript"></script><script src="faq_files/styles.js" type="text/javascript"></script></head>

<body>
	<!--[if !IE]>start wrapper<![endif]-->
	<div id="wrapper">
		<!--[if !IE]>start head<![endif]-->
		<div id="head">
			<div class="inner">
				<h1 id="logo"><a href="#">Meta Admin v1 Clever Adminstration Panel</a></h1>
				<!--[if !IE]>start user details<![endif]-->
				<div id="user_details">
					<ul id="user_details_menu">
						<li class="first">Welcome <strong>Username</strong></li>
						<li><a href="http://localhost/myshop/admin/admin-upload.php?url=change">Change username &amp; password</a></li>
						<li class="last"><a href="http://localhost/myshop/admin/logout.php">Log out</a></li>
					</ul>
					
				</div>
				
				
				<!--[if !IE]>start main menu<![endif]-->
				<div id="main_menu">
					
				</div>
				<!--[if !IE]>end main menu<![endif]-->
				
			</div>
		</div>
		<!--[if !IE]>end head<![endif]-->
		<!--[if !IE]>start content<![endif]-->
		<div id="content">
			
			<!--[if !IE]>start content bottom<![endif]-->
			<div id="content_bottom">
			
			<div class="inner">
				
				<!--[if !IE]>start info<![endif]-->
				<div id="info">
					
					
					
					<!--[if !IE]>start section<![endif]-->
					<div class="section"></div>
					
					
	<table width="100%">
<tbody><tr><td height="40"><h3> Manage Pages</h3></td></tr>
<tr><td>
<form action="" method="post" enctype="multipart/form-data">
Menu
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
 -
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
 <input name="pagename" value="Frequently Asked Questions." type="text">

</form></td></tr><tr><td height="10"></td></tr>

<tr><td>Title
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
 -
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<input name="pagetitle" value="Frequently Asked Questions" type="text">

</td></tr>
<tr><td height="10"></td></tr>
<tr><td>
<div>
			<script src="faq_files/ckeditor.js"></script>

			<textarea id="elm1" name="elm1" rows="25" cols="80" style="width: 50%; visibility: hidden; display: none;">&lt;p
 style="text-align: justify;"&gt;&lt;span style="color: #000080; 
font-size: small;"&gt;&lt;strong&gt;Frequently asked 
questions&lt;/strong&gt; are listed questions and answers, all  supposed
 to be commonly asked in some context, and pertaining to a  particular 
topic. Since the &lt;a class="mw-redirect" title="Acronym" 
href="http://en.wikipedia.org/wiki/Acronym"&gt;acronym&lt;/a&gt; 
&lt;em&gt;FAQ&lt;/em&gt; originated in textual media, its &lt;a 
href="http://en.wikipedia.org/wiki/Pronunciation"&gt;pronunciation&lt;/a&gt;
 varies; "fack," "fax," "facts," and "F.A.Q." are commonly heard.  
Depending on usage, the term may refer specifically to a single  
frequently asked question, or to an assembled list of many questions and
  their answers.&lt;/span&gt;&lt;/p&gt;
&lt;p style="text-align: justify;"&gt;&nbsp;&lt;/p&gt;
&lt;h2&gt;&lt;span id="Origins" 
class="mw-headline"&gt;Origins&lt;/span&gt;&lt;/h2&gt;
&lt;p style="text-align: justify;"&gt;&lt;span style="color: #333399; 
font-size: small;"&gt;While the name may be recent, the FAQ format 
itself is quite old. For instance, &lt;a 
href="http://en.wikipedia.org/wiki/Matthew_Hopkins"&gt;Matthew 
Hopkins&lt;/a&gt; wrote &lt;em&gt;The Discovery of Witches&lt;/em&gt; in
 1647 in FAQ format. He introduces it as "Certaine Queries answered," 
... Many old &lt;a title="Catechism" 
href="http://en.wikipedia.org/wiki/Catechism"&gt;catechisms&lt;/a&gt; 
are in a question-and-answer (Q&amp;A) format. &lt;a 
href="http://en.wikipedia.org/wiki/Summa_Theologica"&gt;Summa 
Theologica&lt;/a&gt;, written by &lt;a 
href="http://en.wikipedia.org/wiki/Thomas_Aquinas"&gt;Thomas 
Aquinas&lt;/a&gt; in the second half of the 13th century, is a series of
 common questions about Christianity to which he wrote his reply to 
each.&lt;/span&gt;&lt;/p&gt;
&lt;p style="text-align: justify;"&gt;&lt;span style="color: #333399; 
font-size: small;"&gt;The "FAQ" is an &lt;a 
href="http://en.wikipedia.org/wiki/Internet"&gt;Internet&lt;/a&gt; 
textual tradition originating from a combination of mailing list-&lt;a 
href="http://en.wikipedia.org/wiki/Laziness"&gt;laziness&lt;/a&gt; plus 
speculation and a separate technical and political need within &lt;a 
href="http://en.wikipedia.org/wiki/NASA"&gt;NASA&lt;/a&gt; in the early 
1980s. The first FAQ developed over several pre-Web years  starting from
 1982 when storage was expensive. On the SPACE mailing  list, the 
presumption was that new users would &lt;a class="mw-redirect" 
title="Ftp" href="http://en.wikipedia.org/wiki/Ftp"&gt;ftp&lt;/a&gt; 
archived past messages. In practice, this never happened. Instead, the  
dynamic on mailing lists was for users to speculate rather than use very
  basic original sources (contacting NASA which was not part of &lt;a 
title="DARPA" 
href="http://en.wikipedia.org/wiki/DARPA"&gt;ARPA&lt;/a&gt; and had only
 one site on the &lt;a 
href="http://en.wikipedia.org/wiki/ARPANET"&gt;ARPANET&lt;/a&gt;) to get
 simple answers. Repeating the "right" answers becomes tedious; it went 
against developing &lt;a 
href="http://en.wikipedia.org/wiki/Netiquette"&gt;netiquette&lt;/a&gt;: 
"Thanks in advance, I will summarize" and didn't. A series of different 
measures from regularly posted messages to &lt;a 
href="http://en.wikipedia.org/wiki/Netlib"&gt;netlib&lt;/a&gt;-like 
query &lt;a href="http://en.wikipedia.org/wiki/Email"&gt;email&lt;/a&gt;
 &lt;a title="Daemon (computer software)" 
href="http://en.wikipedia.org/wiki/Daemon_%28computer_software%29"&gt;daemons&lt;/a&gt;
 were set up by loosely affiliated groups of computer system 
administrators. The acronym &lt;em&gt;FAQ&lt;/em&gt; was developed in 
1983 by Eugene Miya of NASA for the SPACE mailing list.&lt;sup 
id="cite_ref-faqsaboutfaqs_0-0" class="reference"&gt;&lt;a 
href="http://en.wikipedia.org/wiki/FAQ#cite_note-faqsaboutfaqs-0"&gt;[1]&lt;/a&gt;&lt;/sup&gt;
 (Miya notes that Mark Horton's "18 question" periodic post (PP)  
happened concurrent to the SPACE FAQ, although it was not labelled with 
 the word &lt;em&gt;FAQ&lt;/em&gt;.) The format was then picked up on 
other mailing  lists. Posting frequency changed to monthly, and finally 
weekly and  daily across a variety of mailing lists and newsgroups. The 
first person  to post a weekly FAQ was &lt;a 
href="http://en.wikipedia.org/wiki/Jef_Poskanzer"&gt;Jef 
Poskanzer&lt;/a&gt; to the &lt;a 
href="http://en.wikipedia.org/wiki/Usenet"&gt;Usenet&lt;/a&gt; &lt;a 
class="external text" rel="nofollow" 
href="news:net.graphics"&gt;net.graphics&lt;/a&gt;/&lt;a class="external
 text" rel="nofollow" 
href="news:comp.graphics"&gt;comp.graphics&lt;/a&gt; &lt;a 
class="mw-redirect" title="Newsgroup" 
href="http://en.wikipedia.org/wiki/Newsgroup"&gt;newsgroups&lt;/a&gt;.  
Eugene Miya experimented with the first daily FAQ. The first FAQ were  
initially attacked by some mailing list users for being 
repetitive.&lt;/span&gt;&lt;/p&gt;</textarea><div id="cke_elm1" class="cke_1 cke cke_reset cke_chrome cke_editor_elm1 cke_ltr cke_browser_gecko" dir="ltr" role="application" aria-labelledby="cke_elm1_arialbl" lang="en"><span id="cke_elm1_arialbl" class="cke_voice_label">Rich Text Editor, elm1</span><div class="cke_inner cke_reset" role="presentation"><span id="cke_1_top" class="cke_top cke_reset_all" role="presentation" style="height: auto; -moz-user-select: none;"><span id="cke_5" class="cke_voice_label">Editor toolbars</span><span id="cke_1_toolbox" class="cke_toolbox" role="group" aria-labelledby="cke_5" onmousedown="return false;"><span id="cke_6" class="cke_toolbar" aria-labelledby="cke_6_label" role="toolbar"><span id="cke_6_label" class="cke_voice_label">Basic Styles</span><span class="cke_toolbar_start"></span><span class="cke_toolgroup" role="presentation"><a id="cke_7" class="cke_button cke_button__bold cke_button_off" title="Bold (Ctrl+B)" tabindex="-1" hidefocus="true" role="button" aria-labelledby="cke_7_label" aria-describedby="cke_7_description" aria-haspopup="false" onblur="this.style.cssText = this.style.cssText;" onkeydown="return CKEDITOR.tools.callFunction(0,event);" onfocus="return CKEDITOR.tools.callFunction(1,event);" onclick="CKEDITOR.tools.callFunction(2,this);return false;"><span class="cke_button_icon cke_button__bold_icon" style="background-image:url('http://cdn.ckeditor.com/4.6.2/basic/plugins/icons.png?t=H0CG');background-position:0 -24px;background-size:auto;">&nbsp;</span><span id="cke_7_label" class="cke_button_label cke_button__bold_label" aria-hidden="false">Bold</span><span id="cke_7_description" class="cke_button_label" aria-hidden="false">Keyboard shortcut Ctrl+B</span></a><a id="cke_8" class="cke_button cke_button__italic cke_button_off" title="Italic (Ctrl+I)" tabindex="-1" hidefocus="true" role="button" aria-labelledby="cke_8_label" aria-describedby="cke_8_description" aria-haspopup="false" onblur="this.style.cssText = this.style.cssText;" onkeydown="return CKEDITOR.tools.callFunction(3,event);" onfocus="return CKEDITOR.tools.callFunction(4,event);" onclick="CKEDITOR.tools.callFunction(5,this);return false;"><span class="cke_button_icon cke_button__italic_icon" style="background-image:url('http://cdn.ckeditor.com/4.6.2/basic/plugins/icons.png?t=H0CG');background-position:0 -48px;background-size:auto;">&nbsp;</span><span id="cke_8_label" class="cke_button_label cke_button__italic_label" aria-hidden="false">Italic</span><span id="cke_8_description" class="cke_button_label" aria-hidden="false">Keyboard shortcut Ctrl+I</span></a></span><span class="cke_toolbar_end"></span></span><span id="cke_9" class="cke_toolbar" aria-labelledby="cke_9_label" role="toolbar"><span id="cke_9_label" class="cke_voice_label">Paragraph</span><span class="cke_toolbar_start"></span><span class="cke_toolgroup" role="presentation"><a id="cke_10" class="cke_button cke_button__numberedlist cke_button_off" title="Insert/Remove Numbered List" tabindex="-1" hidefocus="true" role="button" aria-labelledby="cke_10_label" aria-describedby="cke_10_description" aria-haspopup="false" onblur="this.style.cssText = this.style.cssText;" onkeydown="return CKEDITOR.tools.callFunction(6,event);" onfocus="return CKEDITOR.tools.callFunction(7,event);" onclick="CKEDITOR.tools.callFunction(8,this);return false;"><span class="cke_button_icon cke_button__numberedlist_icon" style="background-image:url('http://cdn.ckeditor.com/4.6.2/basic/plugins/icons.png?t=H0CG');background-position:0 -576px;background-size:auto;">&nbsp;</span><span id="cke_10_label" class="cke_button_label cke_button__numberedlist_label" aria-hidden="false">Insert/Remove Numbered List</span><span id="cke_10_description" class="cke_button_label" aria-hidden="false"></span></a><a id="cke_11" class="cke_button cke_button__bulletedlist cke_button_off" title="Insert/Remove Bulleted List" tabindex="-1" hidefocus="true" role="button" aria-labelledby="cke_11_label" aria-describedby="cke_11_description" aria-haspopup="false" onblur="this.style.cssText = this.style.cssText;" onkeydown="return CKEDITOR.tools.callFunction(9,event);" onfocus="return CKEDITOR.tools.callFunction(10,event);" onclick="CKEDITOR.tools.callFunction(11,this);return false;"><span class="cke_button_icon cke_button__bulletedlist_icon" style="background-image:url('http://cdn.ckeditor.com/4.6.2/basic/plugins/icons.png?t=H0CG');background-position:0 -528px;background-size:auto;">&nbsp;</span><span id="cke_11_label" class="cke_button_label cke_button__bulletedlist_label" aria-hidden="false">Insert/Remove Bulleted List</span><span id="cke_11_description" class="cke_button_label" aria-hidden="false"></span></a><span class="cke_toolbar_separator" role="separator"></span><a id="cke_12" class="cke_button cke_button__outdent cke_button_disabled " title="Decrease Indent" tabindex="-1" hidefocus="true" role="button" aria-labelledby="cke_12_label" aria-describedby="cke_12_description" aria-haspopup="false" aria-disabled="true" onblur="this.style.cssText = this.style.cssText;" onkeydown="return CKEDITOR.tools.callFunction(12,event);" onfocus="return CKEDITOR.tools.callFunction(13,event);" onclick="CKEDITOR.tools.callFunction(14,this);return false;"><span class="cke_button_icon cke_button__outdent_icon" style="background-image:url('http://cdn.ckeditor.com/4.6.2/basic/plugins/icons.png?t=H0CG');background-position:0 -384px;background-size:auto;">&nbsp;</span><span id="cke_12_label" class="cke_button_label cke_button__outdent_label" aria-hidden="false">Decrease Indent</span><span id="cke_12_description" class="cke_button_label" aria-hidden="false"></span></a><a id="cke_13" class="cke_button cke_button__indent cke_button_off" title="Increase Indent" tabindex="-1" hidefocus="true" role="button" aria-labelledby="cke_13_label" aria-describedby="cke_13_description" aria-haspopup="false" onblur="this.style.cssText = this.style.cssText;" onkeydown="return CKEDITOR.tools.callFunction(15,event);" onfocus="return CKEDITOR.tools.callFunction(16,event);" onclick="CKEDITOR.tools.callFunction(17,this);return false;"><span class="cke_button_icon cke_button__indent_icon" style="background-image:url('http://cdn.ckeditor.com/4.6.2/basic/plugins/icons.png?t=H0CG');background-position:0 -336px;background-size:auto;">&nbsp;</span><span id="cke_13_label" class="cke_button_label cke_button__indent_label" aria-hidden="false">Increase Indent</span><span id="cke_13_description" class="cke_button_label" aria-hidden="false"></span></a></span><span class="cke_toolbar_end"></span></span><span id="cke_14" class="cke_toolbar" aria-labelledby="cke_14_label" role="toolbar"><span id="cke_14_label" class="cke_voice_label">Links</span><span class="cke_toolbar_start"></span><span class="cke_toolgroup" role="presentation"><a id="cke_15" class="cke_button cke_button__link cke_button_off" title="Link (Ctrl+L)" tabindex="-1" hidefocus="true" role="button" aria-labelledby="cke_15_label" aria-describedby="cke_15_description" aria-haspopup="false" onblur="this.style.cssText = this.style.cssText;" onkeydown="return CKEDITOR.tools.callFunction(18,event);" onfocus="return CKEDITOR.tools.callFunction(19,event);" onclick="CKEDITOR.tools.callFunction(20,this);return false;"><span class="cke_button_icon cke_button__link_icon" style="background-image:url('http://cdn.ckeditor.com/4.6.2/basic/plugins/icons.png?t=H0CG');background-position:0 -456px;background-size:auto;">&nbsp;</span><span id="cke_15_label" class="cke_button_label cke_button__link_label" aria-hidden="false">Link</span><span id="cke_15_description" class="cke_button_label" aria-hidden="false">Keyboard shortcut Ctrl+L</span></a><a id="cke_16" class="cke_button cke_button__unlink cke_button_disabled " title="Unlink" tabindex="-1" hidefocus="true" role="button" aria-labelledby="cke_16_label" aria-describedby="cke_16_description" aria-haspopup="false" aria-disabled="true" onblur="this.style.cssText = this.style.cssText;" onkeydown="return CKEDITOR.tools.callFunction(21,event);" onfocus="return CKEDITOR.tools.callFunction(22,event);" onclick="CKEDITOR.tools.callFunction(23,this);return false;"><span class="cke_button_icon cke_button__unlink_icon" style="background-image:url('http://cdn.ckeditor.com/4.6.2/basic/plugins/icons.png?t=H0CG');background-position:0 -480px;background-size:auto;">&nbsp;</span><span id="cke_16_label" class="cke_button_label cke_button__unlink_label" aria-hidden="false">Unlink</span><span id="cke_16_description" class="cke_button_label" aria-hidden="false"></span></a></span><span class="cke_toolbar_end"></span></span><span id="cke_17" class="cke_toolbar cke_toolbar_last" aria-labelledby="cke_17_label" role="toolbar"><span id="cke_17_label" class="cke_voice_label">about</span><span class="cke_toolbar_start"></span><span class="cke_toolgroup" role="presentation"><a id="cke_18" class="cke_button cke_button__about cke_button_off" title="About CKEditor" tabindex="-1" hidefocus="true" role="button" aria-labelledby="cke_18_label" aria-describedby="cke_18_description" aria-haspopup="false" onblur="this.style.cssText = this.style.cssText;" onkeydown="return CKEDITOR.tools.callFunction(24,event);" onfocus="return CKEDITOR.tools.callFunction(25,event);" onclick="CKEDITOR.tools.callFunction(26,this);return false;"><span class="cke_button_icon cke_button__about_icon" style="background-image:url('http://cdn.ckeditor.com/4.6.2/basic/plugins/icons.png?t=H0CG');background-position:0 0px;background-size:auto;">&nbsp;</span><span id="cke_18_label" class="cke_button_label cke_button__about_label" aria-hidden="false">About CKEditor</span><span id="cke_18_description" class="cke_button_label" aria-hidden="false"></span></a></span><span class="cke_toolbar_end"></span></span></span></span><div style="height: 200px;" id="cke_1_contents" class="cke_contents cke_reset" role="presentation"><iframe allowtransparency="true" tabindex="0" title="Rich Text Editor, elm1" class="cke_wysiwyg_frame cke_reset" style="width: 100%; height: 100%;" src="" frameborder="0"></iframe></div></div></div>
			<script>
 CKEDITOR.replace( 'elm1' );
</script>
		</div>
</td></tr>
<tr><td height="10"></td></tr>
<tr><td>
</td></tr>
<tr><td height="10"></td></tr>

<tr><td>
<input name="submit" value="submit" type="submit">
</td></tr>
</tbody></table>
	
				
				</div>
				
				<!--[if !IE]>start sidebar<![endif]-->
				<div id="sidebar">
					
					
					<!--[if !IE]>start sidebar module<![endif]-->
					<div class="sidebar_module">
						<div class="title_wrapper">
							<h3>Secondary Menu</h3>
						</div>
						<div id="secondary_menu">
							<ul>
								<li><a href="http://localhost/myshop/admin/admin-upload.php?url=category">Add Category</a></li>
								<li><a href="http://localhost/myshop/admin/admin-upload.php?url=product">Add Product</a></li>
								<li><a href="http://localhost/myshop/admin/admin-upload.php?url=item">Add Item</a></li>
								<li><a href="http://localhost/myshop/admin/admin-upload.php?url=whats-new">Add What's New</a></li>
								
								
								<li><a href="http://localhost/myshop/admin/admin-upload.php?url=page&amp;id=1">About Us..</a></li><li><a href="http://localhost/myshop/admin/admin-upload.php?url=page&amp;id=2">Frequently Asked Questions.</a></li><li><a href="http://localhost/myshop/admin/admin-upload.php?url=page&amp;id=3">Contact Us</a></li>							</ul>
						</div>
					</div>
					<!--[if !IE]>end sidebar module<![endif]-->
					
					
				</div>
				<!--[if !IE]>end sidebar<![endif]-->
				
				
				
				
				
			</div>
			<!--[if !IE]>end content bottom<![endif]-->
			</div>
			
		</div>
		<!--[if !IE]>end content<![endif]-->
	</div>
	<!--[if !IE]>end wrapper<![endif]-->
	
	<!--[if !IE]>start footer<![endif]-->
	<div id="footer">
	<h2 style="color:#ffffff; text-align:center;"> � All Rights Reserved.	</h2>
	</div>
	<!--[if !IE]>end footer<![endif]-->
	
	


</body></html>