<?php

include("connect.php");
if(isset($_POST["submit"])) {

$product="";


if(isset($_POST["product"])) {
	$product=	$_POST['product'];
	
if(isset($_POST["category"])) {
	$catid=	$_POST['category'];
}
	$r=mysql_query("insert into tblproduct(product,catid)values('$prod',$catid)");
}

if($r>0)
{
echo "<script type='text/javascript'>alert('product added successfully...')</script>";
}	
}
$result=mysql_query("select * from tblcat");

?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title>Meta Admin - Administration Clever Panel</title>
<link rel="stylesheet" type="text/css" href="css/meta-admin.css">
<!-- blue theme is default -->

<link rel="stylesheet" type="text/css" href="css/grey-theme.css">



<!-- text editor -->



<!-- text editor -->
	
	<!-- TinyMCE -->
<<script type="text/javascript" src="js/tiny_mce.js"></script>
<script type="text/javascript">
	tinyMCE.init({
		// General options
		mode : "textareas",
		theme : "advanced",
		plugins : "pagebreak,style,layer,table,save,advhr,advimage,advlink,emotions,iespell,inlinepopups,insertdatetime,preview,media,searchreplace,print,contextmenu,paste,directionality,fullscreen,noneditable,visualchars,nonbreaking,xhtmlxtras,template,wordcount,advlist,autosave",

		// Theme options
		theme_advanced_buttons1 : "save,newdocument,|,bold,italic,underline,strikethrough,|,justifyleft,justifycenter,justifyright,justifyfull,styleselect,formatselect,fontselect,fontsizeselect",
		theme_advanced_buttons2 : "cut,copy,paste,pastetext,pasteword,|,search,replace,|,bullist,numlist,|,outdent,indent,blockquote,|,undo,redo,|,link,unlink,anchor,image,cleanup,help,code,|,insertdate,inserttime,preview,|,forecolor,backcolor",
		theme_advanced_buttons3 : "tablecontrols,|,hr,removeformat,visualaid,|,sub,sup,|,charmap,emotions,iespell,media,advhr,|,print,|,ltr,rtl,|,fullscreen",
		theme_advanced_buttons4 : "insertlayer,moveforward,movebackward,absolute,|,styleprops,|,cite,abbr,acronym,del,ins,attribs,|,visualchars,nonbreaking,template,pagebreak,restoredraft",
		theme_advanced_toolbar_location : "top",
		theme_advanced_toolbar_align : "left",
		theme_advanced_statusbar_location : "bottom",
		theme_advanced_resizing : true,

		// Example content CSS (should be your site CSS)
		content_css : "css/content.css",

		// Drop lists for link/image/media/template dialogs
		template_external_list_url : "lists/template_list.js",
		external_link_list_url : "lists/link_list.js",
		external_image_list_url : "lists/image_list.js",
		media_external_list_url : "lists/media_list.js",

		// Style formats
		style_formats : [
			{title : 'Bold text', inline : 'b'},
			{title : 'Red text', inline : 'span', styles : {color : '#ff0000'}},
			{title : 'Red header', block : 'h1', styles : {color : '#ff0000'}},
			{title : 'Example 1', inline : 'span', classes : 'example1'},
			{title : 'Example 2', inline : 'span', classes : 'example2'},
			{title : 'Table styles'},
			{title : 'Table row 1', selector : 'tr', classes : 'tablerow1'}
		],

		// Replace values for the template plugin
		template_replace_values : {
			username : "Some User",
			staffid : "991234"
		}
	});
</script>



</head>


<body>

<!--[if !IE]>start wrapper<![endif]-->
	<div id="wrapper">
		<!--[if !IE]>start head<![endif]-->
		<div id="head">
			<div class="inner">
				<h1 id="logo"><a href="#">Meta Admin v1 Clever Adminstration Panel</a></h1>
				<!--[if !IE]>start user details<![endif]-->
				<div id="user_details">
					<ul id="user_details_menu">
						<li class="first">Welcome <strong>Username</strong></li>
						<li><a href="http://localhost/myshop/admin/admin-upload.php?url=change">Change username &amp; password</a></li>
						<li class="last"><a href="logout.php">Log out</a></li>
					</ul>
					
				</div>
				
				
				<!--[if !IE]>start main menu<![endif]-->
				<div id="main_menu">
					
				</div>
				<!--[if !IE]>end main menu<![endif]-->
				
			</div>
		</div>
		<!--[if !IE]>end head<![endif]-->
		<!--[if !IE]>start content<![endif]-->
		<div id="content">
			
			<!--[if !IE]>start content bottom<![endif]-->
			<div id="content_bottom">
			
			<div class="inner">
				
				<!--[if !IE]>start info<![endif]-->
				<div id="info">
					
					
					
					<!--[if !IE]>start section<![endif]-->
					<div class="section"></div>
					

<div class="section">
						
					
						<div class="title_wrapper">
							<h2>Add Product</h2>
							
						</div>
						
						
						<!--[if !IE]>start section inner <![endif]-->
						<div class="section_inner">
						
						<!--[if !IE]>start forms<![endif]-->
						<form action="" method=post class="search_form general_form">
							<!--[if !IE]>start fieldset<![endif]-->
							<fieldset>
								<!--[if !IE]>start forms<![endif]-->
								<div class="forms">
								<h3>You can add products here...</h3>
								<!--[if !IE]>start row<![endif]-->
								
								
								
			
			
						<div class=row>
									<label>Choose Category:</label>
									<div class=inputs>
									
									<select name=category>
									<option selected="selected" value="">---- Choose Category ----</option>
									<?php
								while($row = mysql_fetch_array($result)){
									?>
								
									<option value='<?php echo $row['cid']?>'><?php echo $row['catname']?> </option>
									
							<?php
							}
							?>	
						
				<span style="color:#c13d28;"></span>
								
					  		</div>
							
							</div>
			

			
			
			
					<div class=row>
									<label>Product:</label>
									<div class=inputs>
				<span class=input_wrapper><input class=text  type=text name=product></input></span>
											
					<span class="system negative"></span>
					</div>
							</div>
							
								
								
								<div class="row">
								<div class="inputs">
								<input type="submit" name="submit" value="Submit"></input>
										
								</div>
								</div>
								
								
								
								
								
								</div>
								<!--[if !IE]>end forms<![endif]-->
									
							</fieldset>
							<!--[if !IE]>end fieldset<![endif]-->
			
						</form>
						<!--[if !IE]>end forms<![endif]-->
						
						
						
					
					
					
					</div>
					<!--[if !IE]>end section inner<![endif]-->
					
					
					</div>
					<!--[if !IE]>end section<![endif]-->
					
				
				
				
				
				<div class="section">
					<div class="title_wrapper">
						<h2>Products</h2>
						
					</div>
					
					
					<!--[if !IE]>start section_inner<![endif]-->
					<div class="section_inner">
					
					<div  id="product_list">
						
					
						<!--[if !IE]>start table_wrapper<![endif]-->
						<div class="table_wrapper">
							<div class="table_wrapper_inner">
							<table cellpadding="0" cellspacing="0" width="100%">
								<tbody><tr>

									<th>No.</th>
									
									
									<th><a href="#" class="asc">Product</a></th>
									
								
									
									<th>Actions</th>
								</tr>
		<?php						
		
$outcome = mysql_query("select * from tblproduct");

while($row = mysql_fetch_array($outcome)){
 
?>  
							
								<tr class="first">
									<td><?php  echo $row['pid'] ?></td>
									
									<td><a href="#" class="product_name"><?php  echo $row['product']; ?></a></td>
									
									
							
									<td>
										<div class="actions_menu">
											<ul>
												
												<li><a class="edit" href="admin-upload.php?url=edit-product&edit=<?php  echo $row['id'];?>&cid=<?php  echo $row['s_id'];?>">Edit</a></li>
												<li><a class="delete" href="admin-upload.php?url=product&del=<?php  echo $row['id'];?>">Delete</a></li>
											</ul>
										</div>
									</td>
								</tr>
			<?php
}
?>			
								
							</tbody></table>
							</div>
						</div>
						<!--[if !IE]>end table_wrapper<![endif]-->
						

					</div>
					</div>
					<!--[if !IE]>end section inner<![endif]-->
					
					
					</div>
				
					<!--[if !IE]>end section<![endif]-->
					<!--[if !IE]>start sidebar<![endif]-->
				<div id="sidebar">
					
					
					<!--[if !IE]>start sidebar module<![endif]-->
					<div class="sidebar_module">
						<div class="title_wrapper">
							<h3>Secondary Menu</h3>
						</div>
						<div id="secondary_menu">
							<ul>
								<li><a href="addcat.php">Add Category</a></li>
								<li><a href="product.php">Add Product</a></li>
								<li><a href="additem.php">Add Item</a></li>
								<li><a href="contactus.php">Contact Us</a></li>
								
								
								<li><a href="http://localhost/myshop/admin/admin-upload.php?url=page&amp;id=1">About Us..</a></li><li><a href="http://localhost/myshop/admin/admin-upload.php?url=page&amp;id=2">Frequently Asked Questions.</a></li><li><a href="http://localhost/myshop/admin/admin-upload.php?url=page&amp;id=3">Contact Us</a></li>							</ul>
						</div>
					</div>
					<!--[if !IE]>end sidebar module<![endif]-->
					
					
				</div>
				<!--[if !IE]>end sidebar<![endif]-->
				
				
				
				
				
			</div>
			<!--[if !IE]>end content bottom<![endif]-->
			</div>
			
		</div>
		<!--[if !IE]>end content<![endif]-->
	</div>
	<!--[if !IE]>end wrapper<![endif]-->
	
	<!--[if !IE]>start footer<![endif]-->
	<div id="footer">
	<h2 style="color:#ffffff; text-align:center;"> � All Rights Reserved.	</h2>
	</div>
	<!--[if !IE]>end footer<![endif]-->
</body>
</html>					
					
					
					