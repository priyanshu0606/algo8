
<?php
include("connect.php");

$sql="SELECT * FROM tblcategory";
$result = mysql_query($sql);

if(isset($_POST["submit"])) {

$catname="";
$cat2="";
$cat3="";
$cat4="";
$cat5="";

if(isset($_GET['id'])) {
	$id=$_GET['id'];
}
if(isset($_POST["editor1"])) {
	$catname=	$_POST['editor1'];
}
if(isset($_POST["category2"])) {
	$cat2=	$_POST['category2'];
}
if(isset($_POST["category3"])) {
	$cat3=	$_POST['category3'];
}
if(isset($_POST["category4"])) {
	$cat4=	$_POST['category4'];
}
if(isset($_POST["category5"])) {
	$cat5=	$_POST['category5'];
}
$query="update tblcategory set category1='$catname', category2='$cat2', category3='$cat3', category4='$cat4', category5='$cat5'  where id=$id";
$sql11=($query);
$f=mysql_query($sql11);

if($f>0){
	echo "<script type='text/javascript'>alert('Category updated successfully...')</script>";
}
else{
	mysql_error();
	echo "<script type='text/javascript'>alert('Error')</script>";
}
header("location:addcat.php");
}

$sql="SELECT * FROM tblcategory where id='$_GET[id]'";
$result = mysql_query($sql);
$row = mysql_fetch_array($result);
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title>Meta Admin Clever Panel</title>
<link rel="stylesheet" type="text/css" href="css/meta-admin.css">
<!-- blue theme is default -->

<link rel="stylesheet" type="text/css" href="css/grey-theme.css">


<!-- text editor -->
	
	
	<!-- TinyMCE -->
<script type="text/javascript" src="Meta%20Admin%20-%20Administration%20Clever%20Panel_files/tiny_mce.js"></script>
<script type="text/javascript">
	tinyMCE.init({
		// General options
		mode : "textareas",
		theme : "advanced",
		plugins : "pagebreak,style,layer,table,save,advhr,advimage,advlink,emotions,iespell,inlinepopups,insertdatetime,preview,media,searchreplace,print,contextmenu,paste,directionality,fullscreen,noneditable,visualchars,nonbreaking,xhtmlxtras,template,wordcount,advlist,autosave",

		// Theme options
		theme_advanced_buttons1 : "save,newdocument,|,bold,italic,underline,strikethrough,|,justifyleft,justifycenter,justifyright,justifyfull,styleselect,formatselect,fontselect,fontsizeselect",
		theme_advanced_buttons2 : "cut,copy,paste,pastetext,pasteword,|,search,replace,|,bullist,numlist,|,outdent,indent,blockquote,|,undo,redo,|,link,unlink,anchor,image,cleanup,help,code,|,insertdate,inserttime,preview,|,forecolor,backcolor",
		theme_advanced_buttons3 : "tablecontrols,|,hr,removeformat,visualaid,|,sub,sup,|,charmap,emotions,iespell,media,advhr,|,print,|,ltr,rtl,|,fullscreen",
		theme_advanced_buttons4 : "insertlayer,moveforward,movebackward,absolute,|,styleprops,|,cite,abbr,acronym,del,ins,attribs,|,visualchars,nonbreaking,template,pagebreak,restoredraft",
		theme_advanced_toolbar_location : "top",
		theme_advanced_toolbar_align : "left",
		theme_advanced_statusbar_location : "bottom",
		theme_advanced_resizing : true,

		// Example content CSS (should be your site CSS)
		content_css : "css/content.css",

		// Drop lists for link/image/media/template dialogs
		template_external_list_url : "lists/template_list.js",
		external_link_list_url : "lists/link_list.js",
		external_image_list_url : "lists/image_list.js",
		media_external_list_url : "lists/media_list.js",

		// Style formats
		style_formats : [
			{title : 'Bold text', inline : 'b'},
			{title : 'Red text', inline : 'span', styles : {color : '#ff0000'}},
			{title : 'Red header', block : 'h1', styles : {color : '#ff0000'}},
			{title : 'Example 1', inline : 'span', classes : 'example1'},
			{title : 'Example 2', inline : 'span', classes : 'example2'},
			{title : 'Table styles'},
			{title : 'Table row 1', selector : 'tr', classes : 'tablerow1'}
		],

		// Replace values for the template plugin
		template_replace_values : {
			username : "Some User",
			staffid : "991234"
		}
	});
</script>
</head>

<body>
	<!--[if !IE]>start wrapper<![endif]-->
	<div id="wrapper">
		<!--[if !IE]>start head<![endif]-->
		<div id="head">
			<div class="inner">
				<h1 id="logo"><a href="#">Meta Adminstration Panel</a></h1>
				<!--[if !IE]>start user details<![endif]-->
				<div id="user_details">
					<ul id="user_details_menu">
						<li class="first">Welcome <strong>admin</strong></li>
						<li><a href="changepwd.php">Change username &amp; password</a></li>
							<li><a href="welcome.php">Home</a></li>
						<li class="last"><a href="logout.php">Log out</a></li>
					</ul>
					
				</div>
				
				
				<!--[if !IE]>start main menu<![endif]-->
				<div id="main_menu">
					
				</div>
				<!--[if !IE]>end main menu<![endif]-->
				
			</div>
		</div>
		<!--[if !IE]>end head<![endif]-->
		<!--[if !IE]>start content<![endif]-->
		<div id="content">
			
			<!--[if !IE]>start content bottom<![endif]-->
			<div id="content_bottom">
			
			<div class="inner">
				
				<!--[if !IE]>start info<![endif]-->
				<div id="info">
					
					
					
					<!--[if !IE]>start section<![endif]-->
					<div class="section"></div>
					
					
	
		  
								
	

<div class="section">
						
						
						<div class="title_wrapper">
							<h2>Edit Category:</h2>
							
						</div>
						
						
						<!--[if !IE]>start section inner <![endif]-->
						<div class="section_inner">
						
						<!--[if !IE]>start forms<![endif]-->
						<form action="" method="post" enctype="multipart/form-data" class="search_form general_form">
							<!--[if !IE]>start fieldset<![endif]-->
							<fieldset>
								<!--[if !IE]>start forms<![endif]-->
								<div class="forms">
								
								<!--[if !IE]>start row<![endif]-->
								
								<div class="row">
									<label>Category1:</label>
									<div class="inputs">
										<script type="text/javascript" src="ckeditor/ckeditor/ckeditor.js"></script>
                                        <textarea class="ckeditor" name="editor1" rows="10" cols="100" value='<?php echo $row['category1']?>'><?php echo $row['category1']?></textarea>
										<span class="input_wrapper">
                                         </span><span class="system negative"></span>
										
									</div>
								</div>
								
								
								<div class="row">
									<label>Category2:</label>
									<div class="inputs">
										<span class="input_wrapper"><input class="text" name="category2" value='<?php echo $row['category2']?>' type="text"></span><span class="system negative"></span>
										
									</div>
								</div>
								
								
								<div class="row">
									<label>Category3:</label>
									<div class="inputs">
										<span class="input_wrapper"><input class="text" name="category3" value='<?php echo $row['category3']?>' type="text"></span><span class="system negative"></span>
										
									</div>
								</div>
								
								
								<div class="row">
									<label>Category4: </label>
									<div class="inputs">
									<span class="input_wrapper"><input class="text" name="category4" value='<?php echo $row['category4']?>' type="text"></span><span class="system negative"></span>
									</div>
								</div>
								
								<div class="row">
									<label>Category5: </label>
									<div class="inputs">
									<span class="input_wrapper"><input class="text" name="category5" value='<?php echo $row['category5']?>' type="text"></span><span class="system negative"></span>
									</div>
								</div>
								
								<div class="row">
								<div class="inputs">
								<input name="submit" value="Submit" type="submit">
										
								</div>
								</div>
								
								
								
								
								</div>
								<!--[if !IE]>end forms<![endif]-->
									
							</fieldset>
							<!--[if !IE]>end fieldset<![endif]-->
			
						</form>
						<!--[if !IE]>end forms<![endif]-->
						
						
						
					
					
					
					</div>
					<!--[if !IE]>end section inner<![endif]-->
					
					
					</div>
					<!--[if !IE]>end section<![endif]-->
					
					
				<!--[if !IE]>end section<![endif]-->	
				
				</div>
				
				<!--[if !IE]>start sidebar<![endif]-->
				<div id="sidebar">
					
					
					<!--[if !IE]>start sidebar module<![endif]-->
					<div class="sidebar_module">
						<div class="title_wrapper">
							<h3>Secondary Menu</h3>
						</div>
						<div id="secondary_menu">
								<?php include('rightnav.php');?>	
					</div>
					</div>
					<!--[if !IE]>end sidebar module<![endif]-->
					
					
				</div>
				<!--[if !IE]>end sidebar<![endif]-->
				
				
				
				
				
			</div>
			<!--[if !IE]>end content bottom<![endif]-->
			</div>
			
		</div>
		<!--[if !IE]>end content<![endif]-->
	</div>
	<!--[if !IE]>end wrapper<![endif]-->
	
	<!--[if !IE]>start footer<![endif]-->
	<div id="footer">
	<h2 style="color:#ffffff; text-align:center;"> � All Rights Reserved.	</h2>
	</div>
	<!--[if !IE]>end footer<![endif]-->
	
	


</body></html>