<?php
//session_start();

error_reporting(E_ALL);
error_reporting( ~E_NOTICE );
$con = mysql_connect("198.71.225.57:3306","algo8ai","5Wfim00$");
mysql_select_db("algo8",$con);
?>