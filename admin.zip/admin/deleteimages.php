<?php
include('connect.php');
$id="";
if(isset($_GET['id']))
{
	$id=$_GET['id'];
}

$result=mysql_query("delete from tblimages where id=$id");

if(!$result)
{
  die('Could not delete data: ' . mysql_error());
}
else{
header("location:images.php");
}
?>