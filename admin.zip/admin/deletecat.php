<?php
include('connect.php');

$id="";
if(isset($_GET['id']))
{
	$id=$_GET['id'];
}

$result=mysql_query("delete from tblcategory where id=$id");
if($result>0)
{
echo "<script type='text/javascript'>alert('Category deleted successfully...')</script>";
}	
else{
if(!$result)
{
  die('Could not delete data: ' . mysql_error());
}
}
header("location:addcat.php");

?>